#! /bin/bash


if [[ "$#" != "3" && "$#" != "4" ]]
then
    echo "Uso:"
    echo "create_vm_extra_3.sh <nombre_maquina> <grupo_de_recursos> <usuario>  optional: <region>"
    exit 2
fi

az group list > /dev/null 2>&1

if [ $? -eq 1 ]
then
    echo "No logeado en Azure, ejecute 'az login'"
    exit 1
fi
echo "Inserte la contraseña de la VM"
read Pass_VM

if [ $# -eq 3 ]
then
 az vm create \
  --resource-group "$2" \
  --name "$1" \
  --image "Debian" \
  --admin-username "$3"\
  --admin-password "$Pass_VM"\
  --location "northeurope" > /dev/null 2>&1
fi

if [ $# -eq 4 ]
then
 az vm create \
  --resource-group "$2" \
  --name "$1" \
  --image "Debian" \
  --admin-username "$3"\
  --admin-password "$Pass_VM"\
  --location "$4" > /dev/null 2>&1 
fi

az vm auto-shutdown\
  --resource-group "$2" \
  --name "$1" \
  --time 2359 > /dev/null 2>&1 

if [ $? -eq 0 ]
then
    echo "VM creada satisfactoriamente"
    exit 0
fi

echo "Error al crear VM"
exit 1
