#! /bin/bash

if [ 3 -gt "$#" ]
then
 echo "Uso:"
 echo "container_add.sh <nombre_cuenta_almacenamiento>  <nombre_contenedor> <nombre_archivo>"
 exit 2
fi

az group list > /dev/null 2>&1

if [ $? -eq 1 ]
then
    echo "No logeado en Azure, ejecute 'az login'"
    exit 1
fi

N_var=1

for v in $@; do
 if [ "$N_var" -gt 2 ]
 then
  az storage blob upload \
  --account-name "$1" \
  --container-name "$2" \
  --file "$v" \
  --overwrite > /dev/null 2>&1
 fi
 ((N_var+=1))
done

if [ $? -eq 0 ]
then
    echo "Blob creado satisfactoriamente"
    exit 0
fi

echo "Error al crear blob"
exit 1
