#! /bin/bash


if [ "$#" != "3" ]
then
    echo "Uso:"
    echo "create_blob_storage.sh <nombre_cuenta_almacenamiento> <grupo_de_recursos> <nombre_contenedor>"
    exit 2
fi

az group list > /dev/null 2>&1

if [ $? -eq 1 ]
then
    echo "No logeado en Azure, ejecute 'az login'"
    exit 1
fi

az storage account create \
 --name "$1" \
 --resource-group "$2" \
 --allow-blob-public-access 'true' \
 --sku "Standard_LRS" \
 --min-tls-version "TLS1_2" > /dev/null 2>&1

az storage container create \
 --name "$3" \
 --resource-group "$2" \
 --account-name "$1" \
 --public-access "blob" > /dev/null 2>&1


if [ $? -eq 0 ]
then
    echo "Storage account y container creados satisfactoriamente"
    exit 0
fi

echo "Error al crear Storage account y container"
exit 1
