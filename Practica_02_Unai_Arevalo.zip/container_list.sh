#! /bin/bash


if [ "$#" != "2" ]
then
    echo "Uso:"
    echo "container_list.sh <nombre_cuenta_almacenamiento> <nombre_contenedor>"
    exit 2
fi

az group list > /dev/null 2>&1

if [ $? -eq 1 ]
then
    echo "No logeado en Azure, ejecute 'az login'"
    exit 1
fi
 
az storage container set-permission \
 --name "$2" \
 --account-name "$1" \
 --public-access "container" > /dev/null 2>&1

list=$(az storage blob list \
    --container-name "$2" \
    --account-name "$1") 

az storage container set-permission \
 --name "$2" \
 --account-name "$1" \
 --public-access "blob" > /dev/null 2>&1

if [ $? -eq 0 ]
then
    echo -e "Lista de archivos: \n"
    echo "$list"
    exit 0
fi

echo "Error al listar"
exit 1