import requests
from datetime import datetime, timezone, timedelta
import logging
import azure.functions as func
#Pasar el lugar ej America/Mexico_City que se quiera obtener

def main(req: func.HttpRequest) -> func.HttpResponse:

    time_zone = req.params.get('time_zone')
    if not time_zone:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('time_zone')

    if time_zone:
        response = requests.get(f"https://worldtimeapi.org/api/timezone/{time_zone}")
        data = response.json()
        datetime_str = data["datetime"]
        datetime_obj = datetime.fromisoformat(datetime_str)
        return func.HttpResponse(f"{datetime_obj}",status_code=200)
    else:
        response = requests.get(f"https://worldtimeapi.org/api/ip")
        data = response.json()
        datetime_str = data["utc_datetime"]
        datetime_obj = datetime.fromisoformat(datetime_str)        
        
        return func.HttpResponse(f"{datetime_obj}",status_code=200)