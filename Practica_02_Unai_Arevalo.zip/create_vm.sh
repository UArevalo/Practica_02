#! /bin/bash


if [[ "$#" != "4" && "$#" != "5" ]]
then
    echo "Uso:"
    echo "create_vm.sh <nombre_maquina> <grupo_de_recursos> <usuario> <password> optional: <region>"
    exit 2
fi

az group list > /dev/null 2>&1

if [ $? -eq 1 ]
then
    echo "No logeado en Azure, ejecute 'az login'"
    exit 1
fi

if [ $# -eq 4 ]
then
 az vm create \
  --resource-group "$2" \
  --name "$1" \
  --image "Debian" \
  --admin-username "$3"\
  --admin-password "$4"\
  --location "northeurope" > /dev/null 2>&1
fi

if [ $# -eq 5 ]
then
 az vm create \
  --resource-group "$2" \
  --name "$1" \
  --image "Debian" \
  --admin-username "$3"\
  --admin-password "$4"\
  --location "$5" > /dev/null 2>&1 
fi

az vm auto-shutdown\
  --resource-group "$2" \
  --name "$1" \
  --time 2359 > /dev/null 2>&1 

if [ $? -eq 0 ]
then
    echo "VM creada satisfactoriamente"
    exit 0
fi

echo "Error al crear VM"
exit 1