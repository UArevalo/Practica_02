from datetime import datetime, timezone, timedelta
import logging

import azure.functions as func
#Pasar el numero de UTC que se quiera obtener

def main(req: func.HttpRequest) -> func.HttpResponse:

    time_zone = req.params.get('time_zone')
    if not time_zone:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('time_zone')

    if time_zone:
        time_z = timezone(timedelta(hours=int(time_zone)))

        hora_tz = datetime.now(time_z)

        return func.HttpResponse(f"{hora_tz}",status_code=200)
    else:
        now = datetime.now()
        return func.HttpResponse(f"{now}",status_code=200)