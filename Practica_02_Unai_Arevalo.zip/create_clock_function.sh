#! /bin/bash

if [ "$#" != "3" ]
then
 echo "Uso:"
 echo "create_clock_function.sh <nombre_funcion>  <grupo_de_recursos> <nombre_archivo_codigo>(Time_Zone o Time_Zone_Extra)"
 exit 2
fi


az group list > /dev/null 2>&1

if [ $? -eq 1 ]
then
    echo "No logeado en Azure, ejecute 'az login'"
    exit 1
fi

func init "$1" --python > /dev/null 2>&1

cp -r "$3" "$1"/ > /dev/null 2>&1


az functionapp create \
 --name "$1" \
 --resource-group "$2" \
 --storage-account "storagepruebaajshdaf" \
 --runtime "python" \
 --os-type "Linux" \
 --consumption-plan-location "northeurope" \
 --runtime-version 3.9 > /dev/null 2>&1



sleep 10

cd "$1"

#func pack  #--output-package pakage.zip 



func azure functionapp publish "$1" #--package "$1".zip --chsharp 


if [ $? -eq 0 ]
then
    echo "Funcion creada satisfactoriamente"
    exit 0
fi

echo "Error al crear funcion"
exit 1